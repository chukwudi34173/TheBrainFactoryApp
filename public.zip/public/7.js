(window["webpackJsonp"] = window["webpackJsonp"] || []).push([[7],{

/***/ "./node_modules/babel-loader/lib/index.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/Pages/Manager/Index.vue?vue&type=script&lang=js":
/*!******************************************************************************************************************************************************************!*\
  !*** ./node_modules/babel-loader/lib??ref--4-0!./node_modules/vue-loader/lib??vue-loader-options!./resources/js/Pages/Manager/Index.vue?vue&type=script&lang=js ***!
  \******************************************************************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, exports) {

throw new Error("Module build failed (from ./node_modules/babel-loader/lib/index.js):\nSyntaxError: /Users/mac/Sites/brainFactoryRegistrationApp/resources/js/Pages/Manager/Index.vue: Unexpected token, expected \",\" (263:38)\n\n\u001b[0m \u001b[90m 261 |\u001b[39m           \u001b[36mthis\u001b[39m\u001b[33m.\u001b[39mdata\u001b[33m.\u001b[39mdatasets[\u001b[35m0\u001b[39m]\u001b[33m.\u001b[39mdata \u001b[33m=\u001b[39m [\n \u001b[90m 262 |\u001b[39m             \u001b[36mthis\u001b[39m\u001b[33m.\u001b[39mpiechart_data\u001b[33m.\u001b[39m\u001b[33mBECE\u001b[39m\u001b[33m,\u001b[39m\n\u001b[31m\u001b[1m>\u001b[22m\u001b[39m\u001b[90m 263 |\u001b[39m             \u001b[36mthis\u001b[39m\u001b[33m.\u001b[39mpiechart_data\u001b[33m.\u001b[39m\u001b[33mCOMMON\u001b[39m \u001b[33mENTRANCE\u001b[39m\u001b[33m,\u001b[39m\n \u001b[90m     |\u001b[39m                                       \u001b[31m\u001b[1m^\u001b[22m\u001b[39m\n \u001b[90m 264 |\u001b[39m             \u001b[36mthis\u001b[39m\u001b[33m.\u001b[39mpiechart_data\u001b[33m.\u001b[39m\u001b[33mGCE\u001b[39m\u001b[33m,\u001b[39m\n \u001b[90m 265 |\u001b[39m             \u001b[36mthis\u001b[39m\u001b[33m.\u001b[39mpiechart_data\u001b[33m.\u001b[39m\u001b[33mLECTURESECTIONAFTERNOON\u001b[39m\u001b[33m,\u001b[39m\n \u001b[90m 266 |\u001b[39m             \u001b[36mthis\u001b[39m\u001b[33m.\u001b[39mpiechart_data\u001b[33m.\u001b[39m\u001b[33mLECTURESECTIONMORNING\u001b[39m\u001b[33m,\u001b[39m\u001b[0m\n    at constructor (/Users/mac/Sites/brainFactoryRegistrationApp/node_modules/@babel/parser/lib/index.js:351:19)\n    at Parser.raise (/Users/mac/Sites/brainFactoryRegistrationApp/node_modules/@babel/parser/lib/index.js:3233:19)\n    at Parser.unexpected (/Users/mac/Sites/brainFactoryRegistrationApp/node_modules/@babel/parser/lib/index.js:3253:16)\n    at Parser.expect (/Users/mac/Sites/brainFactoryRegistrationApp/node_modules/@babel/parser/lib/index.js:3557:28)\n    at Parser.parseExprList (/Users/mac/Sites/brainFactoryRegistrationApp/node_modules/@babel/parser/lib/index.js:11646:14)\n    at Parser.parseArrayLike (/Users/mac/Sites/brainFactoryRegistrationApp/node_modules/@babel/parser/lib/index.js:11557:26)\n    at Parser.parseExprAtom (/Users/mac/Sites/brainFactoryRegistrationApp/node_modules/@babel/parser/lib/index.js:10844:23)\n    at Parser.parseExprSubscripts (/Users/mac/Sites/brainFactoryRegistrationApp/node_modules/@babel/parser/lib/index.js:10568:23)\n    at Parser.parseUpdate (/Users/mac/Sites/brainFactoryRegistrationApp/node_modules/@babel/parser/lib/index.js:10551:21)\n    at Parser.parseMaybeUnary (/Users/mac/Sites/brainFactoryRegistrationApp/node_modules/@babel/parser/lib/index.js:10529:23)\n    at Parser.parseMaybeUnaryOrPrivate (/Users/mac/Sites/brainFactoryRegistrationApp/node_modules/@babel/parser/lib/index.js:10383:61)\n    at Parser.parseExprOps (/Users/mac/Sites/brainFactoryRegistrationApp/node_modules/@babel/parser/lib/index.js:10388:23)\n    at Parser.parseMaybeConditional (/Users/mac/Sites/brainFactoryRegistrationApp/node_modules/@babel/parser/lib/index.js:10365:23)\n    at Parser.parseMaybeAssign (/Users/mac/Sites/brainFactoryRegistrationApp/node_modules/@babel/parser/lib/index.js:10326:21)\n    at Parser.parseMaybeAssign (/Users/mac/Sites/brainFactoryRegistrationApp/node_modules/@babel/parser/lib/index.js:10352:25)\n    at Parser.parseExpressionBase (/Users/mac/Sites/brainFactoryRegistrationApp/node_modules/@babel/parser/lib/index.js:10280:23)\n    at /Users/mac/Sites/brainFactoryRegistrationApp/node_modules/@babel/parser/lib/index.js:10276:39\n    at Parser.allowInAnd (/Users/mac/Sites/brainFactoryRegistrationApp/node_modules/@babel/parser/lib/index.js:11915:16)\n    at Parser.parseExpression (/Users/mac/Sites/brainFactoryRegistrationApp/node_modules/@babel/parser/lib/index.js:10276:17)\n    at Parser.parseStatementContent (/Users/mac/Sites/brainFactoryRegistrationApp/node_modules/@babel/parser/lib/index.js:12356:23)\n    at Parser.parseStatementLike (/Users/mac/Sites/brainFactoryRegistrationApp/node_modules/@babel/parser/lib/index.js:12223:17)\n    at Parser.parseStatementListItem (/Users/mac/Sites/brainFactoryRegistrationApp/node_modules/@babel/parser/lib/index.js:12203:17)\n    at Parser.parseBlockOrModuleBlockBody (/Users/mac/Sites/brainFactoryRegistrationApp/node_modules/@babel/parser/lib/index.js:12780:61)\n    at Parser.parseBlockBody (/Users/mac/Sites/brainFactoryRegistrationApp/node_modules/@babel/parser/lib/index.js:12773:10)\n    at Parser.parseBlock (/Users/mac/Sites/brainFactoryRegistrationApp/node_modules/@babel/parser/lib/index.js:12761:10)\n    at Parser.parseFunctionBody (/Users/mac/Sites/brainFactoryRegistrationApp/node_modules/@babel/parser/lib/index.js:11600:24)\n    at Parser.parseArrowExpression (/Users/mac/Sites/brainFactoryRegistrationApp/node_modules/@babel/parser/lib/index.js:11575:10)\n    at Parser.parseParenAndDistinguishExpression (/Users/mac/Sites/brainFactoryRegistrationApp/node_modules/@babel/parser/lib/index.js:11189:12)\n    at Parser.parseExprAtom (/Users/mac/Sites/brainFactoryRegistrationApp/node_modules/@babel/parser/lib/index.js:10835:23)\n    at Parser.parseExprSubscripts (/Users/mac/Sites/brainFactoryRegistrationApp/node_modules/@babel/parser/lib/index.js:10568:23)\n    at Parser.parseUpdate (/Users/mac/Sites/brainFactoryRegistrationApp/node_modules/@babel/parser/lib/index.js:10551:21)\n    at Parser.parseMaybeUnary (/Users/mac/Sites/brainFactoryRegistrationApp/node_modules/@babel/parser/lib/index.js:10529:23)\n    at Parser.parseMaybeUnaryOrPrivate (/Users/mac/Sites/brainFactoryRegistrationApp/node_modules/@babel/parser/lib/index.js:10383:61)\n    at Parser.parseExprOps (/Users/mac/Sites/brainFactoryRegistrationApp/node_modules/@babel/parser/lib/index.js:10388:23)\n    at Parser.parseMaybeConditional (/Users/mac/Sites/brainFactoryRegistrationApp/node_modules/@babel/parser/lib/index.js:10365:23)\n    at Parser.parseMaybeAssign (/Users/mac/Sites/brainFactoryRegistrationApp/node_modules/@babel/parser/lib/index.js:10326:21)\n    at /Users/mac/Sites/brainFactoryRegistrationApp/node_modules/@babel/parser/lib/index.js:10296:39\n    at Parser.allowInAnd (/Users/mac/Sites/brainFactoryRegistrationApp/node_modules/@babel/parser/lib/index.js:11920:12)\n    at Parser.parseMaybeAssignAllowIn (/Users/mac/Sites/brainFactoryRegistrationApp/node_modules/@babel/parser/lib/index.js:10296:17)\n    at Parser.parseExprListItem (/Users/mac/Sites/brainFactoryRegistrationApp/node_modules/@babel/parser/lib/index.js:11680:18)\n    at Parser.parseCallExpressionArguments (/Users/mac/Sites/brainFactoryRegistrationApp/node_modules/@babel/parser/lib/index.js:10754:22)\n    at Parser.parseCoverCallAndAsyncArrowHead (/Users/mac/Sites/brainFactoryRegistrationApp/node_modules/@babel/parser/lib/index.js:10671:29)\n    at Parser.parseSubscript (/Users/mac/Sites/brainFactoryRegistrationApp/node_modules/@babel/parser/lib/index.js:10608:19)\n    at Parser.parseSubscripts (/Users/mac/Sites/brainFactoryRegistrationApp/node_modules/@babel/parser/lib/index.js:10581:19)\n    at Parser.parseExprSubscripts (/Users/mac/Sites/brainFactoryRegistrationApp/node_modules/@babel/parser/lib/index.js:10572:17)\n    at Parser.parseUpdate (/Users/mac/Sites/brainFactoryRegistrationApp/node_modules/@babel/parser/lib/index.js:10551:21)\n    at Parser.parseMaybeUnary (/Users/mac/Sites/brainFactoryRegistrationApp/node_modules/@babel/parser/lib/index.js:10529:23)\n    at Parser.parseMaybeUnaryOrPrivate (/Users/mac/Sites/brainFactoryRegistrationApp/node_modules/@babel/parser/lib/index.js:10383:61)\n    at Parser.parseExprOps (/Users/mac/Sites/brainFactoryRegistrationApp/node_modules/@babel/parser/lib/index.js:10388:23)\n    at Parser.parseMaybeConditional (/Users/mac/Sites/brainFactoryRegistrationApp/node_modules/@babel/parser/lib/index.js:10365:23)");

/***/ }),

/***/ "./node_modules/babel-loader/lib/index.js?!./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/Pages/Manager/Index.vue?vue&type=template&id=6deff0f7&scoped=true":
/*!****************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/babel-loader/lib??ref--4-0!./node_modules/vue-loader/lib/loaders/templateLoader.js??ref--6!./node_modules/vue-loader/lib??vue-loader-options!./resources/js/Pages/Manager/Index.vue?vue&type=template&id=6deff0f7&scoped=true ***!
  \****************************************************************************************************************************************************************************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "render", function() { return render; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return staticRenderFns; });
var render = function render() {
  var _vm = this,
    _c = _vm._self._c;
  return _c("div", [_c("div", {
    staticClass: "container px-3 px-lg-3 mt-3 mb-4"
  }, [_c("div", {
    staticClass: "fjcomments mx-0 p-4"
  }, [_c("VueElementLoading", {
    attrs: {
      active: _vm.loading,
      spinner: "bar-fade-scale",
      color: "#7E8CF6"
    }
  }), _vm._v(" "), _c("div", {
    staticClass: "row"
  }, [_vm._m(0), _vm._v(" "), _c("div", {
    staticClass: "col-md-12 col-lg-12"
  }, [_vm.view_status ? _c("div", {
    staticClass: "alert alert-warning mt-4 mb-3"
  }, [_c("small", {
    staticClass: "mb-2",
    staticStyle: {
      display: "block",
      color: "red"
    },
    attrs: {
      role: "alert"
    }
  }, [_vm._v("Kindly Endeavor to verify payment before approving candidate\n              information,So as to allow printing")])]) : _vm._e()]), _vm._v(" "), _vm.view_status ? _c("div", {
    staticClass: "col-md-4 col-lg-4 mt-3 mb-3"
  }, [_c("div", {
    staticClass: "input-group"
  }, [_vm._m(1), _vm._v(" "), _c("select", {
    directives: [{
      name: "model",
      rawName: "v-model",
      value: _vm.filters.paid_for,
      expression: "filters.paid_for"
    }],
    staticClass: "form-control custom-select",
    on: {
      change: [function ($event) {
        var $$selectedVal = Array.prototype.filter.call($event.target.options, function (o) {
          return o.selected;
        }).map(function (o) {
          var val = "_value" in o ? o._value : o.value;
          return val;
        });
        _vm.$set(_vm.filters, "paid_for", $event.target.multiple ? $$selectedVal : $$selectedVal[0]);
      }, function ($event) {
        return _vm.getRecord();
      }]
    }
  }, [_c("option", {
    attrs: {
      value: ""
    }
  }, [_vm._v("--select--")]), _vm._v(" "), _c("option", {
    attrs: {
      value: "POST UTME"
    }
  }, [_vm._v("POST UTME")]), _vm._v(" "), _c("option", {
    attrs: {
      value: "jamb"
    }
  }, [_vm._v("JAMB")]), _vm._v(" "), _c("option", {
    attrs: {
      value: "COMMON ENTRANCE"
    }
  }, [_vm._v("COMMON ENTRANCE")]), _vm._v(" "), _c("option", {
    attrs: {
      value: "WAEC (SSS 3)"
    }
  }, [_vm._v("WAEC (SSS 3)")]), _vm._v(" "), _c("option", {
    attrs: {
      value: "NECO (SSS 3)"
    }
  }, [_vm._v("NECO (SSS 3)")]), _vm._v(" "), _c("option", {
    attrs: {
      value: "GCE"
    }
  }, [_vm._v("GCE")]), _vm._v(" "), _c("option", {
    attrs: {
      value: "BECE"
    }
  }, [_vm._v("BECE")]), _vm._v(" "), _c("option", {
    attrs: {
      value: "LECTURE SECTION (MORNING)"
    }
  }, [_vm._v("\n                LECTURE SECTION (MORNING)\n              ")]), _vm._v(" "), _c("option", {
    attrs: {
      value: "LECTURE SECTION (AFTERNOON)"
    }
  }, [_vm._v("\n                LECTURE SECTION (AFTERNOON)\n              ")])])])]) : _vm._e(), _vm._v(" "), _vm.view_status ? _c("div", {
    staticClass: "col-md-4 col-lg-4 mt-3 mb-3"
  }, [_c("div", {
    staticClass: "input-group"
  }, [_vm._m(2), _vm._v(" "), _c("input", {
    directives: [{
      name: "model",
      rawName: "v-model",
      value: _vm.filters.search,
      expression: "filters.search"
    }],
    staticClass: "form-control",
    attrs: {
      type: "text",
      id: "",
      placeholder: "Search name,dob"
    },
    domProps: {
      value: _vm.filters.search
    },
    on: {
      keyup: function keyup($event) {
        return _vm.getRecord();
      },
      input: function input($event) {
        if ($event.target.composing) return;
        _vm.$set(_vm.filters, "search", $event.target.value);
      }
    }
  })])]) : _vm._e(), _vm._v(" "), _vm.view_status ? _c("div", {
    staticClass: "col-md-4 col-lg mt-3 mb-3"
  }, [_c("div", {
    staticClass: "input-group"
  }, [_vm._m(3), _vm._v(" "), _c("select", {
    directives: [{
      name: "model",
      rawName: "v-model",
      value: _vm.filters.status,
      expression: "filters.status"
    }],
    staticClass: "form-control custom-select",
    on: {
      change: [function ($event) {
        var $$selectedVal = Array.prototype.filter.call($event.target.options, function (o) {
          return o.selected;
        }).map(function (o) {
          var val = "_value" in o ? o._value : o.value;
          return val;
        });
        _vm.$set(_vm.filters, "status", $event.target.multiple ? $$selectedVal : $$selectedVal[0]);
      }, function ($event) {
        return _vm.getRecord();
      }]
    }
  }, [_c("option", {
    attrs: {
      value: ""
    }
  }, [_vm._v("--select--")]), _vm._v(" "), _c("option", {
    attrs: {
      value: "1"
    }
  }, [_vm._v("Approved")]), _vm._v(" "), _c("option", {
    attrs: {
      value: "0"
    }
  }, [_vm._v("Pending")])])])]) : _vm._e(), _vm._v(" "), _c("div", {
    staticClass: "col-md-12 col-lg-12 mt-2 mb-2"
  }, [_c("div", {
    staticClass: "d-flex justify-content-between"
  }, [_c("div"), _vm._v(" "), _c("div", {
    staticClass: "btn-actions-pane-right text-capitalize actions-icon-btn"
  }, [_c("toggle-button", {
    attrs: {
      labels: {
        checked: "Table Data",
        unchecked: "Analytics"
      },
      color: {
        checked: "#7DCE94",
        unchecked: "#82C7EB"
      },
      width: 80
    },
    on: {
      change: function change($event) {
        return _vm.TogglePageView();
      }
    },
    model: {
      value: _vm.view_status,
      callback: function callback($$v) {
        _vm.view_status = $$v;
      },
      expression: "view_status"
    }
  })], 1)]), _vm._v(" "), _vm.view_status == true ? _c("div", [_c("VuePerfectScrollbar", [_vm.records ? _c("div", {
    staticClass: "table-responsive mt-2 mb-3"
  }, [_c("table", {
    staticClass: "table table-bordered table-hover"
  }, [_c("thead", [_c("tr", [_c("th", {
    attrs: {
      width: "5%"
    }
  }, [_vm._v("#")]), _vm._v(" "), _c("th", {
    attrs: {
      width: "20%"
    }
  }, [_vm._v("Full Name")]), _vm._v(" "), _c("th", {
    attrs: {
      width: "20%"
    }
  }, [_vm._v("Transaction Refrence Id")]), _vm._v(" "), _c("th", {
    attrs: {
      width: "20%"
    }
  }, [_vm._v("Paid For")]), _vm._v(" "), _c("th", {
    attrs: {
      width: "20%"
    }
  }, [_vm._v("Paid For Description")]), _vm._v(" "), _c("th", {
    attrs: {
      width: "20%"
    }
  }, [_vm._v("DOB")]), _vm._v(" "), _c("th", {
    attrs: {
      width: "20%"
    }
  }, [_vm._v("Dated Registered")]), _vm._v(" "), _c("th", {
    attrs: {
      width: "20%"
    }
  }, [_vm._v("Date Updated")]), _vm._v(" "), _c("th", {
    attrs: {
      width: "5%"
    }
  }, [_vm._v("Status")]), _vm._v(" "), _c("th", {
    attrs: {
      width: "5%"
    }
  }, [_vm._v("Action")])])]), _vm._v(" "), _c("tbody", _vm._l(_vm.records && _vm.records.data && _vm.records.data.data, function (stu, index) {
    return _c("tr", {
      key: index
    }, [_c("td", [_vm._v(_vm._s(index + 1))]), _vm._v(" "), _c("td", [_vm._v("\n                        " + _vm._s(stu.first_name + " " + stu.middle_name + " " + stu.other_name) + "\n                      ")]), _vm._v(" "), _c("td", [_c("span", {
      staticClass: "badge badge-info p-2"
    }, [_vm._v("\n                          " + _vm._s(stu.trans_refrence_id) + "\n                        ")])]), _vm._v(" "), _c("td", [_vm._v(_vm._s(stu.class_tick))]), _vm._v(" "), _c("td", [_vm._v(_vm._s(stu.expected_amount_plan_desc))]), _vm._v(" "), _c("td", [_vm._v(_vm._s(stu.dob))]), _vm._v(" "), _c("td", [_vm._v("\n                        " + _vm._s(_vm._f("moment")(stu.created_at, "dddd, Do MMM. YYYY")) + "\n                      ")]), _vm._v(" "), _c("td", [_vm._v("\n                        " + _vm._s(_vm._f("moment")(stu.updated_at, "dddd, Do MMM. YYYY")) + "\n                      ")]), _vm._v(" "), _c("td", [_c("div", {
      staticClass: "text-sm",
      style: {
        backgroundColor: stu.confirmed == "1" ? "#28a745" : "#ffc107",
        color: stu.confirmed == "1" ? "#fff" : "#000",
        padding: "0.25em 0.5em",
        borderRadius: "0.25rem",
        textAlign: "center"
      }
    }, [_c("span", {
      staticClass: "badge"
    }, [_vm._v("\n                            " + _vm._s(stu.confirmed == "1" ? "Approved" : "Pending") + "\n                          ")])])]), _vm._v(" "), _c("td", [_c("div", {
      staticClass: "btn-actions-pane-right text-capitalize actions-icon-btn"
    }, [_c("b-dropdown", {
      attrs: {
        "toggle-class": "btn-icon btn-icon-only",
        variant: "link",
        right: ""
      }
    }, [_c("span", {
      attrs: {
        slot: "button-content"
      },
      slot: "button-content"
    }, [_c("font-awesome-icon", {
      attrs: {
        icon: "th"
      }
    })], 1), _vm._v(" "), stu.confirmed == "0" ? _c("button", {
      staticClass: "dropdown-item",
      attrs: {
        type: "button",
        tabindex: "0"
      },
      on: {
        click: function click($event) {
          return _vm.Approve(stu);
        }
      }
    }, [_c("i", {
      staticClass: "pe-7s-note icon-gradient bg-grow-early mr-2"
    }), _vm._v(" "), _c("span", {
      staticClass: "text-sm"
    }, [_vm._v("Approve Transaction")])]) : _vm._e()])], 1)])]);
  }), 0)])]) : _c("div", [_c("div", {
    staticClass: "alert alert-info mt-4 mb-3"
  }, [_c("small", {
    staticClass: "mb-2",
    staticStyle: {
      display: "block",
      color: "red"
    },
    attrs: {
      role: "alert"
    }
  }, [_vm._v("No Candidate Have Registered")])])])])], 1) : _vm._e(), _vm._v(" "), _vm.view_status == true ? _c("div", {
    staticClass: "d-flex justify-content-center"
  }, [_vm.records && _vm.records.data ? _c("Pagination", {
    staticClass: "mx-auto d-flex align-items-center",
    attrs: {
      data: _vm.records && _vm.records.data
    },
    on: {
      "pagination-change-page": _vm.getRecord
    }
  }) : _vm._e()], 1) : _vm._e(), _vm._v(" "), _vm.view_status == false ? _c("div", [_c("div", {
    staticClass: "row"
  }, [_c("div", {
    staticClass: "col-md-4 mb-3"
  }, [_c("div", {
    staticClass: "card shadow-sm",
    staticStyle: {
      height: "100% !important"
    }
  }, [_c("div", {
    staticClass: "card-body"
  }, [_c("div", {
    staticClass: "d-flex justify-content-between"
  }, [_c("div"), _vm._v(" "), _c("div", {
    staticClass: "btn-actions-pane-right text-capitalize actions-icon-btn"
  }, [_c("toggle-button", {
    attrs: {
      labels: {
        checked: "Approved",
        unchecked: "Pending"
      },
      color: {
        checked: "#7DCE94",
        unchecked: "#82C7EB"
      },
      width: 80
    },
    on: {
      change: function change($event) {
        return _vm.ToggleBarChart();
      }
    },
    model: {
      value: _vm.bar_status,
      callback: function callback($$v) {
        _vm.bar_status = $$v;
      },
      expression: "bar_status"
    }
  })], 1)]), _vm._v(" "), !_vm.loading ? _c("BarChat", {
    key: _vm.chatComponentKey,
    attrs: {
      chartdata: _vm.chartdata,
      options: _vm.chatoptions
    }
  }) : _vm._e()], 1)])]), _vm._v(" "), _c("div", {
    staticClass: "col-md-4"
  }, [_c("div", {
    staticClass: "card shadow-sm",
    staticStyle: {
      height: "100% !important"
    }
  }, [_c("div", {
    staticClass: "card-body"
  }, [!_vm.loading ? _c("PieChat", {
    key: _vm.chatComponentKey2,
    attrs: {
      data: _vm.data,
      options: _vm.options
    }
  }) : _vm._e()], 1)])]), _vm._v(" "), _c("div", {
    staticClass: "col-md-4"
  }, [_c("div", {
    staticClass: "row"
  }, [_c("div", {
    staticClass: "col-md-12 col-12 col-lg-12 mb-3 mt-3",
    staticStyle: {
      height: "50% !important"
    }
  }, [_c("div", {
    staticClass: "card info-card sales-card",
    staticStyle: {
      "background-color": "#fff !important",
      "margin-bottom": "30px !important",
      border: "none !important",
      "border-radius": "5px !important",
      "box-shadow": "0px 0 30px rgba(1, 41, 112, 0.1)"
    }
  }, [_c("div", {
    staticClass: "card-body"
  }, [_c("h5", {
    staticClass: "card-title"
  }, [_vm._v("APPROVED (PAID) Candidate")]), _vm._v(" "), _c("div", {
    staticClass: "d-flex align-items-center"
  }, [_vm._m(4), _vm._v(" "), _c("div", {
    staticClass: "ps-3"
  }, [_c("h6", [_vm._v("\n                              " + _vm._s(_vm.card_data_approved_candidate && _vm.card_data_approved_candidate[0] && _vm.card_data_approved_candidate[0].card_data_approved_candidate) + "\n                            ")])])])])])]), _vm._v(" "), _c("div", {
    staticClass: "col-md-12 col-12 col-lg-12 border-top pt-5 mt-3 pb-5",
    staticStyle: {
      height: "50% !important"
    }
  }, [_c("div", {
    staticClass: "card info-card sales-card",
    staticStyle: {
      "background-color": "#fff !important",
      "margin-bottom": "30px !important",
      border: "none !important",
      "border-radius": "5px !important",
      "box-shadow": "0px 0 30px rgba(1, 41, 112, 0.1)"
    }
  }, [_c("div", {
    staticClass: "card-body"
  }, [_c("h5", {
    staticClass: "card-title text-warning"
  }, [_vm._v("\n                          PENDING (UNPAID) Candidate\n                        ")]), _vm._v(" "), _c("div", {
    staticClass: "d-flex align-items-center"
  }, [_vm._m(5), _vm._v(" "), _c("div", {
    staticClass: "ps-3"
  }, [_c("h6", [_vm._v("\n                              " + _vm._s(_vm.card_data_pending_candidate && _vm.card_data_pending_candidate[0] && _vm.card_data_pending_candidate[0].card_data_pending_candidate) + "\n                            ")])])])])])])])])])]) : _vm._e()])])], 1)])]);
};
var staticRenderFns = [function () {
  var _vm = this,
    _c = _vm._self._c;
  return _c("div", {
    staticClass: "col-md-12 col-lg-12"
  }, [_c("div", {
    staticClass: "d-flex justify-content-center"
  }, [_c("div", [_c("img", {
    staticClass: "img-fluid",
    attrs: {
      src: "https://s3-us-west-1.amazonaws.com/thebrainfactory/BRAINFACTORYLOGO-black.jpeg",
      id: "img-fluid",
      alt: ""
    }
  })])])]);
}, function () {
  var _vm = this,
    _c = _vm._self._c;
  return _c("div", {
    staticClass: "input-group-prepend"
  }, [_c("span", {
    staticClass: "input-group-text"
  }, [_vm._v("Filter By Paid For")])]);
}, function () {
  var _vm = this,
    _c = _vm._self._c;
  return _c("div", {
    staticClass: "input-group-prepend"
  }, [_c("span", {
    staticClass: "input-group-text"
  }, [_vm._v("Search")])]);
}, function () {
  var _vm = this,
    _c = _vm._self._c;
  return _c("div", {
    staticClass: "input-group-prepend"
  }, [_c("span", {
    staticClass: "input-group-text"
  }, [_vm._v("Filter Status")])]);
}, function () {
  var _vm = this,
    _c = _vm._self._c;
  return _c("div", {
    staticClass: "card-icon rounded-circle d-flex align-items-center justify-content-center"
  }, [_c("i", {
    staticClass: "fa fa-users"
  })]);
}, function () {
  var _vm = this,
    _c = _vm._self._c;
  return _c("div", {
    staticClass: "card-icon2 rounded-circle d-flex align-items-center justify-content-center"
  }, [_c("i", {
    staticClass: "fa fa-users"
  })]);
}];
render._withStripped = true;


/***/ }),

/***/ "./node_modules/css-loader/index.js?!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src/index.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/Pages/Manager/Index.vue?vue&type=style&index=0&id=6deff0f7&scoped=true&lang=css":
/*!*************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/css-loader??ref--6-1!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src??ref--6-2!./node_modules/vue-loader/lib??vue-loader-options!./resources/js/Pages/Manager/Index.vue?vue&type=style&index=0&id=6deff0f7&scoped=true&lang=css ***!
  \*************************************************************************************************************************************************************************************************************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

exports = module.exports = __webpack_require__(/*! ../../../../node_modules/css-loader/lib/css-base.js */ "./node_modules/css-loader/lib/css-base.js")(false);
// imports


// module
exports.push([module.i, "\n.ps-3[data-v-6deff0f7] {\n  padding-left: 1rem !important;\n}\n#img-fluid[data-v-6deff0f7] {\n  border-radius: 50%;\n  width: 200px;\n  height: 200px;\n  text-align: center;\n}\n.card-title[data-v-6deff0f7] {\n  padding: 20px 0 15px 0 !important;\n  font-size: 18px !important;\n  font-weight: 500 !important;\n  color: #017245 !important;\n  font-family: \"Poppins\", sans-serif !important;\n  margin-bottom: 0.5rem !important;\n}\n.card-icon[data-v-6deff0f7],\n.card-icon2[data-v-6deff0f7] {\n  font-size: 32px !important;\n  line-height: 0 !important;\n  width: 64px !important;\n  height: 64px !important;\n  flex-shrink: 0 !important;\n  flex-grow: 0 !important;\n}\n.sales-card .card-icon[data-v-6deff0f7] {\n  color: #4154f1 !important;\n  background: #f6f6fe !important;\n}\n.info-card h6[data-v-6deff0f7] {\n  font-size: 28px !important;\n  color: #012970 !important;\n  font-weight: 700 !important;\n  margin: 0 !important;\n  padding: 0 !important;\n}\n.align-items-center[data-v-6deff0f7] {\n  align-items: center !important;\n}\n.justify-content-center[data-v-6deff0f7] {\n  justify-content: center !important;\n}\n.card-title2[data-v-6deff0f7] {\n  padding: 20px 0 15px 0 !important;\n  font-size: 18px !important;\n  font-weight: 500 !important;\n  color: #017245 !important;\n  font-family: \"Poppins\", sans-serif !important;\n}\n.text-warning[data-v-6deff0f7] {\n  color: rgba(255, 193, 7, 1) !important;\n}\n.sales-card .card-icon2[data-v-6deff0f7] {\n  color: #ff771d !important;\n  background: #ffecdf !important;\n}\n", ""]);

// exports


/***/ }),

/***/ "./node_modules/style-loader/index.js!./node_modules/css-loader/index.js?!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src/index.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/Pages/Manager/Index.vue?vue&type=style&index=0&id=6deff0f7&scoped=true&lang=css":
/*!*****************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/style-loader!./node_modules/css-loader??ref--6-1!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src??ref--6-2!./node_modules/vue-loader/lib??vue-loader-options!./resources/js/Pages/Manager/Index.vue?vue&type=style&index=0&id=6deff0f7&scoped=true&lang=css ***!
  \*****************************************************************************************************************************************************************************************************************************************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {


var content = __webpack_require__(/*! !../../../../node_modules/css-loader??ref--6-1!../../../../node_modules/vue-loader/lib/loaders/stylePostLoader.js!../../../../node_modules/postcss-loader/src??ref--6-2!../../../../node_modules/vue-loader/lib??vue-loader-options!./Index.vue?vue&type=style&index=0&id=6deff0f7&scoped=true&lang=css */ "./node_modules/css-loader/index.js?!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src/index.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/Pages/Manager/Index.vue?vue&type=style&index=0&id=6deff0f7&scoped=true&lang=css");

if(typeof content === 'string') content = [[module.i, content, '']];

var transform;
var insertInto;



var options = {"hmr":true}

options.transform = transform
options.insertInto = undefined;

var update = __webpack_require__(/*! ../../../../node_modules/style-loader/lib/addStyles.js */ "./node_modules/style-loader/lib/addStyles.js")(content, options);

if(content.locals) module.exports = content.locals;

if(false) {}

/***/ }),

/***/ "./resources/js/Pages/Manager/Index.vue":
/*!**********************************************!*\
  !*** ./resources/js/Pages/Manager/Index.vue ***!
  \**********************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _Index_vue_vue_type_template_id_6deff0f7_scoped_true__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./Index.vue?vue&type=template&id=6deff0f7&scoped=true */ "./resources/js/Pages/Manager/Index.vue?vue&type=template&id=6deff0f7&scoped=true");
/* harmony import */ var _Index_vue_vue_type_script_lang_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./Index.vue?vue&type=script&lang=js */ "./resources/js/Pages/Manager/Index.vue?vue&type=script&lang=js");
/* empty/unused harmony star reexport *//* harmony import */ var _Index_vue_vue_type_style_index_0_id_6deff0f7_scoped_true_lang_css__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./Index.vue?vue&type=style&index=0&id=6deff0f7&scoped=true&lang=css */ "./resources/js/Pages/Manager/Index.vue?vue&type=style&index=0&id=6deff0f7&scoped=true&lang=css");
/* harmony import */ var _node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../../../../node_modules/vue-loader/lib/runtime/componentNormalizer.js */ "./node_modules/vue-loader/lib/runtime/componentNormalizer.js");






/* normalize component */

var component = Object(_node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_3__["default"])(
  _Index_vue_vue_type_script_lang_js__WEBPACK_IMPORTED_MODULE_1__["default"],
  _Index_vue_vue_type_template_id_6deff0f7_scoped_true__WEBPACK_IMPORTED_MODULE_0__["render"],
  _Index_vue_vue_type_template_id_6deff0f7_scoped_true__WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"],
  false,
  null,
  "6deff0f7",
  null
  
)

/* hot reload */
if (false) { var api; }
component.options.__file = "resources/js/Pages/Manager/Index.vue"
/* harmony default export */ __webpack_exports__["default"] = (component.exports);

/***/ }),

/***/ "./resources/js/Pages/Manager/Index.vue?vue&type=script&lang=js":
/*!**********************************************************************!*\
  !*** ./resources/js/Pages/Manager/Index.vue?vue&type=script&lang=js ***!
  \**********************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_babel_loader_lib_index_js_ref_4_0_node_modules_vue_loader_lib_index_js_vue_loader_options_Index_vue_vue_type_script_lang_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../node_modules/babel-loader/lib??ref--4-0!../../../../node_modules/vue-loader/lib??vue-loader-options!./Index.vue?vue&type=script&lang=js */ "./node_modules/babel-loader/lib/index.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/Pages/Manager/Index.vue?vue&type=script&lang=js");
/* empty/unused harmony star reexport */ /* harmony default export */ __webpack_exports__["default"] = (_node_modules_babel_loader_lib_index_js_ref_4_0_node_modules_vue_loader_lib_index_js_vue_loader_options_Index_vue_vue_type_script_lang_js__WEBPACK_IMPORTED_MODULE_0__["default"]); 

/***/ }),

/***/ "./resources/js/Pages/Manager/Index.vue?vue&type=style&index=0&id=6deff0f7&scoped=true&lang=css":
/*!******************************************************************************************************!*\
  !*** ./resources/js/Pages/Manager/Index.vue?vue&type=style&index=0&id=6deff0f7&scoped=true&lang=css ***!
  \******************************************************************************************************/
/*! no static exports found */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_style_loader_index_js_node_modules_css_loader_index_js_ref_6_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_6_2_node_modules_vue_loader_lib_index_js_vue_loader_options_Index_vue_vue_type_style_index_0_id_6deff0f7_scoped_true_lang_css__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../node_modules/style-loader!../../../../node_modules/css-loader??ref--6-1!../../../../node_modules/vue-loader/lib/loaders/stylePostLoader.js!../../../../node_modules/postcss-loader/src??ref--6-2!../../../../node_modules/vue-loader/lib??vue-loader-options!./Index.vue?vue&type=style&index=0&id=6deff0f7&scoped=true&lang=css */ "./node_modules/style-loader/index.js!./node_modules/css-loader/index.js?!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src/index.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/Pages/Manager/Index.vue?vue&type=style&index=0&id=6deff0f7&scoped=true&lang=css");
/* harmony import */ var _node_modules_style_loader_index_js_node_modules_css_loader_index_js_ref_6_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_6_2_node_modules_vue_loader_lib_index_js_vue_loader_options_Index_vue_vue_type_style_index_0_id_6deff0f7_scoped_true_lang_css__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_style_loader_index_js_node_modules_css_loader_index_js_ref_6_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_6_2_node_modules_vue_loader_lib_index_js_vue_loader_options_Index_vue_vue_type_style_index_0_id_6deff0f7_scoped_true_lang_css__WEBPACK_IMPORTED_MODULE_0__);
/* harmony reexport (unknown) */ for(var __WEBPACK_IMPORT_KEY__ in _node_modules_style_loader_index_js_node_modules_css_loader_index_js_ref_6_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_6_2_node_modules_vue_loader_lib_index_js_vue_loader_options_Index_vue_vue_type_style_index_0_id_6deff0f7_scoped_true_lang_css__WEBPACK_IMPORTED_MODULE_0__) if(["default"].indexOf(__WEBPACK_IMPORT_KEY__) < 0) (function(key) { __webpack_require__.d(__webpack_exports__, key, function() { return _node_modules_style_loader_index_js_node_modules_css_loader_index_js_ref_6_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_6_2_node_modules_vue_loader_lib_index_js_vue_loader_options_Index_vue_vue_type_style_index_0_id_6deff0f7_scoped_true_lang_css__WEBPACK_IMPORTED_MODULE_0__[key]; }) }(__WEBPACK_IMPORT_KEY__));


/***/ }),

/***/ "./resources/js/Pages/Manager/Index.vue?vue&type=template&id=6deff0f7&scoped=true":
/*!****************************************************************************************!*\
  !*** ./resources/js/Pages/Manager/Index.vue?vue&type=template&id=6deff0f7&scoped=true ***!
  \****************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_babel_loader_lib_index_js_ref_4_0_node_modules_vue_loader_lib_loaders_templateLoader_js_ref_6_node_modules_vue_loader_lib_index_js_vue_loader_options_Index_vue_vue_type_template_id_6deff0f7_scoped_true__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../node_modules/babel-loader/lib??ref--4-0!../../../../node_modules/vue-loader/lib/loaders/templateLoader.js??ref--6!../../../../node_modules/vue-loader/lib??vue-loader-options!./Index.vue?vue&type=template&id=6deff0f7&scoped=true */ "./node_modules/babel-loader/lib/index.js?!./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/Pages/Manager/Index.vue?vue&type=template&id=6deff0f7&scoped=true");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "render", function() { return _node_modules_babel_loader_lib_index_js_ref_4_0_node_modules_vue_loader_lib_loaders_templateLoader_js_ref_6_node_modules_vue_loader_lib_index_js_vue_loader_options_Index_vue_vue_type_template_id_6deff0f7_scoped_true__WEBPACK_IMPORTED_MODULE_0__["render"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return _node_modules_babel_loader_lib_index_js_ref_4_0_node_modules_vue_loader_lib_loaders_templateLoader_js_ref_6_node_modules_vue_loader_lib_index_js_vue_loader_options_Index_vue_vue_type_template_id_6deff0f7_scoped_true__WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"]; });



/***/ })

}]);